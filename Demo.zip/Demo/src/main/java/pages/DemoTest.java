package pages;

import wrappers.ProjectWrappers;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class DemoTest extends ProjectWrappers {

	@BeforeClass
	public void setValues() {
		
		authors = "Rajesh";
		category = "Smoke";
		browserName = "chrome";
		dataSheetName = "TC001";
	}

	@Test
	public void demoRun() {
		
		testCaseName = "Demo_Check";
		testDescription = "Login";
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		
	}
	
	@Test
	public void demoRu12n() {
		
		testCaseName = "Demo_Check_test2";
		testDescription = "Login_Chck";
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		
	}

	/**
	 * Class End
	 */

}
