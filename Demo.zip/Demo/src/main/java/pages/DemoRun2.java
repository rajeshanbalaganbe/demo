package pages;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import wrappers.ProjectWrappers;

public class DemoRun2 extends ProjectWrappers {

	
	@BeforeClass
	public void setValues() {
		
		authors = "Rajesh";
		category = "Smoke";
		browserName = "chrome";
		dataSheetName = "TC001";
	}

	@Test
	public void dhjfgbsdkufnsfhklms() {
		
		testCaseName = "ytrewjudjsdgbjks";
		testDescription = "Logjhjhjin";
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		
	}
	
	@Test
	public void lifjixaclyauiseymn() {
		
		testCaseName = "iofjdkfhjkdfhkhfkslfydp;l";
		testDescription = "Loghjhjhjhin_Chck";
		test = startTestCase(testCaseName, testDescription);
		test.assignCategory(category);
		test.assignAuthor(authors);
		invokeApp(browserName);
		
	}

	
}
